var botaoAdicionar = document.querySelector("#importar-paciente");

botaoAdicionar.addEventListener("click", function(){

  var xhr = new XMLHttpRequest();

  xhr.open("GET", "https://api-pacientes.herokuapp.com/pacienties");

  xhr.addEventListener("load", function(){

    var erro = document.querySelector("#erro-ajax");

    console.log(xhr.status);

    if (xhr.status == 200) {

      var resposta = xhr.responseText;

      var pacientes = JSON.parse(resposta);

      erro.classList.add("invisivel");

      pacientes.forEach(function(paciente) {

        adicionaPacienteNaTabela(paciente);

      })

    }

    else {

      erro.classList.remove("invisivel");

    }

  })

    xhr.send();

});
