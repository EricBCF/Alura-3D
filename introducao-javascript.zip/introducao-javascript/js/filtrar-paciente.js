var campoFiltro = document.querySelector(".filtrar-tabela");

campoFiltro.addEventListener("input", function(){

  var valorAtual = this.value;

  var pacientes = document.querySelectorAll(".paciente");

  pacientes.forEach(function(paciente){

    var nomeDoPaciente = paciente.querySelector(".info-nome").textContent;

    var expressao = new RegExp(valorAtual,"i");

    if(valorAtual.length == 0 || expressao.test(nomeDoPaciente)) {

      paciente.classList.remove("fadeOut");

      paciente.classList.remove("invisivel");

    }

    else{

      paciente.classList.add("fadeOut");

      setTimeout(function(){paciente.classList.add("invisivel")}, 500);

    }

  })

})
